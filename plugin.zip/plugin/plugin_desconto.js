(function($) {

    
    $(function(){

        setInterval(function(){

            console.log('Analisando pagina atual ...')

        }, 500)

    });



})(jQuery);

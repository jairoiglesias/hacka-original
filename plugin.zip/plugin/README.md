## Plugin para Chrome

Transforme todas as imagens de um site em fotos do Catossi.
 
http://bit.ly/ncatossi

PRINTS: 

<img src="https://lh3.googleusercontent.com/hp0TQzo23-EbZ4N4E4CJtpAbCrlybCSMTvJRU0-Z9mqO4SfTDOmfP0nPh7OduSYlzajgnunP=s640-h400-e365-rw" title="print ncatossi" />
<br />

<img src="https://lh3.googleusercontent.com/UGaT3VrLbPXxsPQExJF-fI81eCzaYSmk6ODfeVbnzGEitPKSubSJVzzAR8PoEmch_nvAkOY7bA4=s640-h400-e365-rw" title="print ncatossi" />
